(()=>{
'use strict';
const PARTS=4;
async function loadData(){
  try{
    const texts=await Promise.all(Array.from({length:PARTS},(_,i)=>fetch(`./data.part${String(i+1).padStart(2,'0')}`).then(r=>{if(!r.ok)throw new Error(`data part ${i+1} HTTP ${r.status}`);return r.text()})));
    const b64=texts.join('');
    const bin=atob(b64);
    const bytes=new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
    if(!('DecompressionStream' in window))throw new Error('このブラウザは圧縮データ展開に対応していません。OS/Safariを最新版へ更新してください。');
    const ds=new DecompressionStream('gzip');
    const text=await new Response(new Blob([bytes]).stream().pipeThrough(ds)).text();
    window.COMMON_SUBJECT_DATA=JSON.parse(text);
    const s=document.createElement('script');s.src='./app.js?v=2';s.defer=true;document.body.appendChild(s);
  }catch(e){
    console.error(e);
    document.body.innerHTML=`<main style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;padding:24px;max-width:720px;margin:auto"><h1>データを読み込めませんでした</h1><p>${String(e.message||e)}</p><p>オンライン接続を確認して再読み込みしてください。</p></main>`;
  }
}
loadData();
})();
