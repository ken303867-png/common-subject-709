(() => {
'use strict';
const DATA = window.COMMON_SUBJECT_DATA;
const Q = DATA.questions;
const STORE_KEY = 'common_subject_709_pwa_v1';
const DATA_VERSION = DATA.schemaVersion || '1.47';
let state = loadState();
let session = {ids:[], pos:0, mode:'study', answers:{}, uncertain:{}, graded:{}, submitted:false, baseIds:[]};

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const nl = s => esc(s ?? '').replace(/\n/g,'<br>');

function defaultP(){return {attempts:0,correct:0,wrong:0,lastAnswer:null,lastCorrect:null,uncertain:false,bookmarked:false,lastAt:null}}
function normalizeState(s){
  if(!s || typeof s !== 'object') s={};
  if(!s.progress || typeof s.progress !== 'object') s.progress={};
  if(!s.lastSession || typeof s.lastSession !== 'object') s.lastSession=null;
  if(s.dataVersion !== DATA_VERSION){
    // IDs are v1.47-specific. Preserve backups from other versions but do not auto-delete.
    s.dataVersion = DATA_VERSION;
  }
  return s;
}
function loadState(){try{return normalizeState(JSON.parse(localStorage.getItem(STORE_KEY))||{})}catch(_){return normalizeState({})}}
function saveState(){localStorage.setItem(STORE_KEY,JSON.stringify(state)); refreshAll()}
function pget(id){return state.progress[id] || defaultP()}
function pset(id,p){state.progress[id]=p;saveState()}
function byId(id){return Q.find(q=>q.id===id)}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}

const subjects=[...new Set(Q.map(q=>q.subject))];
const types=[...new Set(Q.map(q=>q.questionType))];
const majors=[...new Set(Q.map(q=>q.majorCategory))];

function init(){
  $('#subjectSel').innerHTML='<option value="all">すべて</option>'+subjects.map(v=>`<option>${esc(v)}</option>`).join('');
  $('#majorSel').innerHTML='<option value="all">すべて</option>'+majors.map(v=>`<option>${esc(v)}</option>`).join('');
  $('#typeSel').innerHTML='<option value="all">すべて</option>'+types.map(v=>`<option>${esc(v)}</option>`).join('');
  bind();
  updateMajorOptions();
  refreshAll();
  updateMatchCount();
  $('#dataSummary').innerHTML=`全 <b>${Q.length}</b> 問 ／ ${subjects.length} 科目<br>ID：${esc(Q[0].id)} ～ ${esc(Q[Q.length-1].id)}<br>データバージョン：${esc(DATA_VERSION)}`;
  if('serviceWorker' in navigator && location.protocol !== 'file:'){
    navigator.serviceWorker.register('./sw.js').catch(()=>{});
  }
}
function bind(){
  $('#startBtn').onclick=()=>startFiltered('all');
  $('#resumeBtn').onclick=resumeSession;
  $$('.quick-card').forEach(b=>b.onclick=()=>startFiltered(b.dataset.quick));
  ['subjectSel','majorSel','prioritySel','sourceSel','difficultySel','typeSel','orderSel','limitSel'].forEach(id=>{
    $('#'+id).onchange=()=>{if(id==='subjectSel') updateMajorOptions(); updateMatchCount()}
  });
  $('#submitBtn').onclick=submitAnswer;
  $('#nextBtn').onclick=nextQuestion;
  $('#examNextBtn').onclick=examNext;
  $('#bookmarkBtn').onclick=toggleBookmark;
  $('#uncertainCheck').onchange=()=>{const q=current(); if(!q)return; session.uncertain[q.id]=$('#uncertainCheck').checked};
  $('#leaveStudyBtn').onclick=leaveStudy;
  $('#backHomeBtn').onclick=()=>switchView('home');
  $('#repeatSessionBtn').onclick=repeatSession;
  $$('[data-review]').forEach(b=>b.onclick=()=>reviewFromResult(b.dataset.review));
  $$('.tab').forEach(b=>b.onclick=()=>switchView(b.dataset.view));
  $('#exportBtn').onclick=exportState;
  $('#importFile').onchange=importState;
  $('#resetBtn').onclick=resetState;
  document.addEventListener('keydown',e=>{
    if($('#studyView').classList.contains('hidden')) return;
    if(['INPUT','SELECT','TEXTAREA','BUTTON'].includes(document.activeElement.tagName)) return;
    if(['1','2','3','4'].includes(e.key)){
      const letter=['A','B','C','D'][Number(e.key)-1];
      const radio=document.querySelector(`input[name="answer"][value="${letter}"]`);
      if(radio){radio.checked=true;selectChoice(letter)}
    }else if(e.key==='Enter'){
      if(session.mode==='exam') examNext(); else if(!session.submitted) submitAnswer(); else nextQuestion();
    }
  });
}
function updateMajorOptions(){
  const sub=$('#subjectSel').value;
  const vals=[...new Set(Q.filter(q=>sub==='all'||q.subject===sub).map(q=>q.majorCategory))];
  const old=$('#majorSel').value;
  $('#majorSel').innerHTML='<option value="all">すべて</option>'+vals.map(v=>`<option>${esc(v)}</option>`).join('');
  if(vals.includes(old)) $('#majorSel').value=old;
}
function filterBase(){
  const sub=$('#subjectSel').value, major=$('#majorSel').value, pr=$('#prioritySel').value,
    src=$('#sourceSel').value, diff=$('#difficultySel').value, typ=$('#typeSel').value;
  return Q.filter(q=>(sub==='all'||q.subject===sub)&&(major==='all'||q.majorCategory===major)&&
    (pr==='all'||q.priority===pr)&&(src==='all'||q.sourceType===src)&&(diff==='all'||q.difficulty===diff)&&
    (typ==='all'||q.questionType===typ));
}
function applyQuick(arr, quick){
  return arr.filter(q=>{
    const p=pget(q.id);
    if(quick==='unanswered') return !p.lastAnswer;
    if(quick==='wrong') return p.lastAnswer && p.lastCorrect===false;
    if(quick==='uncertain') return p.uncertain;
    if(quick==='wrong_uncertain') return (p.lastAnswer && p.lastCorrect===false)||p.uncertain;
    if(quick==='bookmarked') return p.bookmarked;
    return true;
  });
}
function selectedIds(quick='all'){
  let arr=applyQuick(filterBase(),quick);
  if($('#orderSel').value==='random') arr=shuffle([...arr]);
  const lim=Number($('#limitSel').value);
  if(lim>0) arr=arr.slice(0,lim);
  return arr.map(q=>q.id);
}
function updateMatchCount(){
  const n=filterBase().length;
  $('#matchCount').textContent=`現在の条件：${n}問`;
}
function startFiltered(quick){
  const ids=selectedIds(quick);
  if(!ids.length){alert('条件に一致する問題がありません。');return}
  session={ids,baseIds:[...ids],pos:0,mode:$('#modeSel').value,answers:{},uncertain:{},graded:{},submitted:false};
  state.lastSession={ids:[...ids],pos:0,mode:session.mode,answers:{},uncertain:{},graded:{},baseIds:[...ids],updatedAt:new Date().toISOString()};
  saveState();
  switchView('study'); renderQuestion();
}
function resumeSession(){
  const s=state.lastSession;
  if(!s||!Array.isArray(s.ids)||!s.ids.length){alert('再開できる前回セッションがありません。');return}
  const valid=s.ids.filter(id=>byId(id));
  if(!valid.length){alert('再開できる問題がありません。');return}
  session={ids:valid,baseIds:Array.isArray(s.baseIds)?s.baseIds.filter(id=>byId(id)):valid,pos:Math.min(s.pos||0,valid.length-1),
    mode:s.mode||'study',answers:s.answers||{},uncertain:s.uncertain||{},graded:s.graded||{},submitted:false};
  switchView('study'); renderQuestion();
}
function current(){return byId(session.ids[session.pos])}
function renderQuestion(){
  const q=current(); if(!q){finishSession();return}
  const previouslyGraded=session.mode==='study' && !!session.graded[q.id];
  session.submitted=previouslyGraded;
  $('#feedbackPanel').classList.add('hidden');
  $('#examNav').classList.toggle('hidden',session.mode!=='exam');
  $('#submitBtn').classList.toggle('hidden',session.mode==='exam'||previouslyGraded);
  $('#counter').textContent=`${session.pos+1} / ${session.ids.length}`;
  $('#sessionProgress').style.width=`${((session.pos+1)/session.ids.length)*100}%`;
  $('#badgeSubject').textContent=q.subject;
  $('#badgePriority').textContent=q.priority;
  $('#badgeDifficulty').textContent=q.difficulty||'';
  $('#badgeSource').textContent=q.sourceType==='既存520'?'既存':'予想';
  $('#topicText').textContent=`${q.majorCategory} › ${q.topic}　｜　${q.questionType}`;
  $('#questionText').textContent=q.question;
  const selected=session.answers[q.id]||null;
  $('#choices').innerHTML=['A','B','C','D'].map(l=>`<label class="choice ${selected===l?'selected':''}" data-letter="${l}">
    <input type="radio" name="answer" value="${l}" ${selected===l?'checked':''} hidden>
    <span class="choice-letter">${l}</span><span>${esc(q['choice'+l])}</span></label>`).join('');
  $$('.choice').forEach(el=>el.onclick=()=>{if(session.submitted)return;const l=el.dataset.letter;session.answers[q.id]=l;selectChoice(l);persistSession()});
  $('#uncertainCheck').checked=!!(session.uncertain[q.id] ?? pget(q.id).uncertain);
  $('#uncertainCheck').disabled=previouslyGraded;
  const p=pget(q.id);
  $('#bookmarkBtn').textContent=p.bookmarked?'★ お気に入り済み':'☆ お気に入り';
  persistSession();
  if(previouslyGraded && selected){showFeedback(q,selected,false);$$('.choice').forEach(el=>el.classList.add('locked'))}
  window.scrollTo({top:0,behavior:'smooth'});
}
function selectChoice(letter){$$('.choice').forEach(el=>el.classList.toggle('selected',el.dataset.letter===letter))}
function persistSession(){
  state.lastSession={ids:[...session.ids],baseIds:[...session.baseIds],pos:session.pos,mode:session.mode,answers:{...session.answers},uncertain:{...session.uncertain},graded:{...session.graded},updatedAt:new Date().toISOString()};
  localStorage.setItem(STORE_KEY,JSON.stringify(state));
}
function submitAnswer(){
  const q=current(); if(!q)return;
  const ans=session.answers[q.id];
  if(!ans){alert('選択肢を選んでください。');return}
  recordAnswer(q,ans);
  session.graded[q.id]=true;
  session.submitted=true;
  persistSession();
  $('#submitBtn').classList.add('hidden');
  $('#uncertainCheck').disabled=true;
  $$('.choice').forEach(el=>el.classList.add('locked'));
  showFeedback(q,ans);
}
function recordAnswer(q,ans,doSave=true){
  const p=pget(q.id);
  const ok=ans===q.answer;
  p.attempts=(p.attempts||0)+1;
  if(ok)p.correct=(p.correct||0)+1;else p.wrong=(p.wrong||0)+1;
  p.lastAnswer=ans;p.lastCorrect=ok;p.uncertain=!!session.uncertain[q.id];p.lastAt=new Date().toISOString();
  state.progress[q.id]=p;
  if(doSave){persistSession();saveState()}
}
function showFeedback(q,ans,scroll=true){
  const ok=ans===q.answer;
  $('#feedbackPanel').classList.remove('hidden');
  $('#feedbackHeader').className='feedback-header '+(ok?'ok':'ng');
  $('#feedbackHeader').textContent=ok?'○ 正解':'× 不正解';
  $('#answerLine').textContent=`正解：${q.answer}　${q['choice'+q.answer]}`;
  $$('.choice').forEach(el=>{const l=el.dataset.letter;el.classList.remove('correct','wrong');if(l===q.answer)el.classList.add('correct');if(l===ans&&!ok)el.classList.add('wrong')});
  $('#explanation').innerHTML=nl(q.explanation);
  $('#optionExplanations').innerHTML=nl(q.optionExplanations);
  $('#whatIsAsked').innerHTML=nl(q.whatIsAsked);
  $('#reasoning').innerHTML=nl(q.reasoning);
  $('#compare').innerHTML=nl(q.compare);
  $('#pitfalls').innerHTML=nl(q.pitfalls);
  $('#correctionConditions').innerHTML=nl(q.correctionConditions);
  $('#relatedKnowledge').innerHTML=nl(q.relatedKnowledge);
  $('#keyPoints').innerHTML=nl(q.keyPoints);
  $('#mnemonic').innerHTML=nl(q.mnemonic);
  $('#sourcesText').innerHTML=nl(q.sources);
  if(scroll) $('#feedbackPanel').scrollIntoView({behavior:'smooth',block:'start'});
}
function nextQuestion(){
  if(!session.submitted){alert('先に解答してください。');return}
  if(session.pos>=session.ids.length-1){finishSession();return}
  session.pos++;renderQuestion();
}
function examNext(){
  const q=current(); if(!q)return;
  const ans=session.answers[q.id];
  if(!ans){alert('選択肢を選んでください。');return}
  if(session.pos>=session.ids.length-1){finishSession();return}
  session.pos++;renderQuestion();
}
function finishSession(){
  if(session.mode==='exam'){
    // Record all exam answers exactly once at completion.
    session.ids.forEach(id=>{const q=byId(id),ans=session.answers[id];if(ans)recordAnswer(q,ans,false)});
  }
  state.lastSession=null;saveState();
  renderResults();switchView('result');
}
function renderResults(){
  const ids=session.ids, rows=ids.map(id=>{const q=byId(id),a=session.answers[id];return {q,a,ok:a===q.answer,unc:!!session.uncertain[id]}});
  const correct=rows.filter(x=>x.ok).length, wrong=rows.length-correct, uncertain=rows.filter(x=>x.unc).length;
  $('#resultRate').textContent=rows.length?Math.round(correct/rows.length*100)+'%':'0%';
  $('#rTotal').textContent=rows.length;$('#rCorrect').textContent=correct;$('#rWrong').textContent=wrong;$('#rUncertain').textContent=uncertain;
  const groups={};rows.forEach(x=>{const s=x.q.subject;(groups[s]??={n:0,c:0}).n++;if(x.ok)groups[s].c++});
  $('#resultSubjects').innerHTML=Object.entries(groups).map(([s,v])=>subjectBar(s,v.c,v.n)).join('');
  $('#examReview').classList.toggle('hidden',session.mode!=='exam');
  if(session.mode==='exam'){
    $('#examReviewList').innerHTML=rows.map((x,i)=>`<div class="exam-review-item">
      <div class="q">${i+1}. ${esc(x.q.question)}</div>
      <div class="${x.ok?'ok':'ng'}">${x.ok?'○ 正解':'× 不正解'}　あなた：${esc(x.a||'未回答')} ／ 正解：${esc(x.q.answer)}</div>
      <details><summary>解説を表示</summary><div class="detail-body"><b>${esc(x.q.answer)}：${esc(x.q['choice'+x.q.answer])}</b><br><br>${nl(x.q.explanation)}<br><br><b>各選択肢</b><br>${nl(x.q.optionExplanations)}</div></details>
    </div>`).join('');
  }
  window.scrollTo({top:0,behavior:'smooth'});
}
function reviewFromResult(kind){
  const arr=session.ids.filter(id=>{
    const q=byId(id),ans=session.answers[id],unc=!!session.uncertain[id],wrong=ans!==q.answer;
    return kind==='wrong'?wrong:kind==='uncertain'?unc:(wrong||unc);
  });
  if(!arr.length){alert('対象となる問題はありません。');return}
  session={ids:arr,baseIds:[...arr],pos:0,mode:'study',answers:{},uncertain:{},graded:{},submitted:false};
  switchView('study');renderQuestion();
}
function repeatSession(){
  const ids=[...session.baseIds];
  session={ids,baseIds:[...ids],pos:0,mode:session.mode,answers:{},uncertain:{},graded:{},submitted:false};
  switchView('study');renderQuestion();
}
function toggleBookmark(){
  const q=current();if(!q)return;const p=pget(q.id);p.bookmarked=!p.bookmarked;state.progress[q.id]=p;saveState();renderQuestion()
}
function leaveStudy(){persistSession();switchView('home')}
function subjectBar(name,c,n){
  const pct=n?Math.round(c/n*100):0;
  return `<div class="subject-row"><div class="subject-name">${esc(name)}</div><div class="mini-bar"><span style="width:${pct}%"></span></div><div class="subject-num">${c}/${n} ${pct}%</div></div>`;
}
function refreshAll(){
  const ps=Q.map(q=>pget(q.id));
  const answered=ps.filter(p=>p.lastAnswer).length,correct=ps.filter(p=>p.lastCorrect===true).length,wrong=ps.filter(p=>p.lastAnswer&&p.lastCorrect===false).length;
  const uncertain=ps.filter(p=>p.uncertain).length,book=ps.filter(p=>p.bookmarked).length,attempts=ps.reduce((s,p)=>s+(p.attempts||0),0);
  $('#topProgress').textContent=`${answered} / ${Q.length}`;
  $('#heroAnswered').textContent=answered;$('#heroCorrect').textContent=correct;$('#heroRate').textContent=answered?Math.round(correct/answered*100)+'%':'-';
  $('#qUnanswered').textContent=`${Q.length-answered}問`;$('#qWrong').textContent=`${wrong}問`;$('#qUncertain').textContent=`${uncertain}問`;
  $('#qWrongUncertain').textContent=`${Q.filter(q=>{const p=pget(q.id);return(p.lastAnswer&&p.lastCorrect===false)||p.uncertain}).length}問`;$('#qBookmarked').textContent=`${book}問`;
  $('#stAnswered').textContent=answered;$('#stCorrect').textContent=correct;$('#stWrong').textContent=wrong;$('#stAttempts').textContent=attempts;$('#stUncertain').textContent=uncertain;$('#stBookmarked').textContent=book;
  const canResume=!!(state.lastSession&&Array.isArray(state.lastSession.ids)&&state.lastSession.ids.length);
  $('#resumeBtn').disabled=!canResume;$('#resumeBtn').textContent=canResume?'前回の続き':'続きなし';
  renderSubjectProgress();
}
function renderSubjectProgress(){
  const html=subjects.map(s=>{
    const qs=Q.filter(q=>q.subject===s),answered=qs.filter(q=>pget(q.id).lastAnswer).length,correct=qs.filter(q=>pget(q.id).lastCorrect===true).length;
    const pct=answered?Math.round(correct/answered*100):0;
    return `<div class="subject-row"><div class="subject-name">${esc(s)}<br><span class="muted">${answered}/${qs.length}回答</span></div><div class="mini-bar"><span style="width:${answered/qs.length*100}%"></span></div><div class="subject-num">${answered?pct+'%':'-'}</div></div>`;
  }).join('');
  $('#subjectProgress').innerHTML=html;$('#statsSubjects').innerHTML=html;
}
function switchView(v){
  ['home','study','result','stats','data'].forEach(x=>$('#'+x+'View').classList.toggle('hidden',x!==v));
  $$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.view===v));
  if(['study','result'].includes(v)) $$('.tabs .tab').forEach(b=>b.classList.remove('active'));
  if(v!=='study') window.scrollTo({top:0,behavior:'smooth'});
}
function exportState(){
  const payload={app:'common-subject-709',dataVersion:DATA_VERSION,exportedAt:new Date().toISOString(),state};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`共通科目709_学習履歴_${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)
}
function importState(e){
  const f=e.target.files[0];if(!f)return;const r=new FileReader();
  r.onload=()=>{try{const o=JSON.parse(r.result),s=o.state||o;if(!s||typeof s!=='object')throw 0;state=normalizeState(s);saveState();alert('学習履歴を読み込みました。')}catch(_){alert('読み込める学習履歴JSONではありません。')}e.target.value=''};
  r.readAsText(f)
}
function resetState(){
  if(!confirm('共通科目709の学習履歴・自信なし・お気に入りをすべてリセットします。よろしいですか？'))return;
  state=normalizeState({});localStorage.setItem(STORE_KEY,JSON.stringify(state));refreshAll();alert('学習履歴をリセットしました。')
}
init();
})();